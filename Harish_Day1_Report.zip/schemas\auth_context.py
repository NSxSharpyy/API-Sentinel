from pydantic import BaseModel, Field, field_validator

class AuthorizationContext(BaseModel):
    user_id: str = Field(..., min_length=1)
    tenant_id: str = Field(..., min_length=1)
    role: str = Field(..., min_length=1)
    object_id: str = Field(..., min_length=1)
    action: str = Field(..., min_length=1)

    @field_validator('action')
    @classmethod
    def normalize_action(cls, value: str) -> str:
        normalized = value.strip().upper()
        valid_actions = {"GET", "POST", "PUT", "DELETE", "PATCH"}
        if normalized not in valid_actions:
            raise ValueError(f"Action '{value}' is not recognized.")
        return normalized

    class Config:
        frozen = True

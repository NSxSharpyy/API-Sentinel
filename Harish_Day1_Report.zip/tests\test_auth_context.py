import unittest
from pydantic import ValidationError
from schemas.auth_context import AuthorizationContext

class TestAuthorizationContext(unittest.TestCase):

    def test_valid_context(self):
        data = {
            "user_id": "usr_777",
            "tenant_id": "srm_tenant",
            "role": "student",
            "object_id": "lab_report_01",
            "action": "get"
        }
        ctx = AuthorizationContext(**data)
        self.assertEqual(ctx.action, "GET")

    def test_invalid_action(self):
        malicious_data = {
            "user_id": "usr_777",
            "tenant_id": "srm_tenant",
            "role": "student",
            "object_id": "lab_report_01",
            "action": "SQL_ATTACK"
        }
        with self.assertRaises(ValidationError):
            AuthorizationContext(**malicious_data)

if __name__ == "__main__":
    unittest.main()
